<html>
    <body>
    <table>
<tr><td>id</td><td>status</td><td>created</td></tr>
<?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr><td><?php echo e($log->id); ?></td><td><?php echo e($log->result); ?></td><td><?php echo e($log->created_at); ?></td></tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    </body>
</html><?php /**PATH F:\philip work\xampp\htdocs\pg\example-app\resources\views/log.blade.php ENDPATH**/ ?>